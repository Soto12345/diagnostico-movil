package com.example.examen_diagnostico_movil

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class activity_menu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)
        val navigationView: NavigationView= findViewById(R.id.navigation_view)

        navigationView.setNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_register -> {
                    val intent = Intent(this, activity_register::class.java)
                    startActivity(intent)
                }
                R.id.nav_consult -> {
                   val intent=Intent(this,activity_view::class.java)
                    startActivity(intent)
                }
                R.id.nav_exit -> {
                    // Cierra la aplicación
                    finish()
                }
            }
            true
        }
    }
}