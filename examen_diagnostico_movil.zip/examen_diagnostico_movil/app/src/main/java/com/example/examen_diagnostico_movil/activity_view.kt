package com.example.examen_diagnostico_movil

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class activity_view : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view)
        // Obtén la referencia al TextView
        val productsTextView: TextView = findViewById(R.id.products_text_view)

        // Obtener la lista de productos desde ProductRepository
        val products = activity_register.ProductRepository.productos

        // Crear una cadena con la información de los productos
        val productsText = products.joinToString(separator = "\n\n") { product ->
            "Nombre: ${product.nombre}\n" +
                    "Precio: ${product.precio}\n" +
                    "Cantidad: ${product.cantidad}\n" +
                    "Categoría: ${product.categoria}\n" +
                    "En stock: ${if (product.isEnStock) "Sí" else "No"}"
        }

        // Mostrar la cadena en el TextView
        productsTextView.text = productsText
    }
}
