package com.example.examen_diagnostico_movil

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    data class UserAccount(val username: String, val password: String)
    private val userAccounts = arrayListOf(
        UserAccount("diego", "12345"),
        UserAccount("ivan", "12345"),
        UserAccount("soto", "12345")
    )
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val username = findViewById<EditText>(R.id.username)
        val password = findViewById<EditText>(R.id.password)
        val loginButton = findViewById<Button>(R.id.login_button)

        loginButton.setOnClickListener {
            val usernameText = username.text.toString()
            val passwordText = password.text.toString()

            if (authenticateUser(usernameText, passwordText)) {
                Toast.makeText(this, "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show()
                // Inicia la actividad ActivityMenu
                val intent = Intent(this, activity_menu::class.java)
                startActivity(intent)
                finish() // Opcional: cierra la actividad MainActivity
            } else {
                Toast.makeText(this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show()
            }
        }
    }
    private fun authenticateUser(username: String, password: String): Boolean {
        return userAccounts.any { it.username == username && it.password == password }
    }

}