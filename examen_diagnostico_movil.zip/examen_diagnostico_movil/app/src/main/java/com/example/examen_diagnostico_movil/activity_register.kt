package com.example.examen_diagnostico_movil

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Toast

class activity_register : AppCompatActivity() {
    object ProductRepository {
        val productos = mutableListOf<Producto>()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        val productName = findViewById<EditText>(R.id.product_name)
        val productPrice = findViewById<EditText>(R.id.product_price)
        val productQuantity = findViewById<EditText>(R.id.product_quantity)
        val productCategory = findViewById<EditText>(R.id.product_category)
        val productInStock = findViewById<CheckBox>(R.id.product_in_stock)
        val saveProductButton = findViewById<Button>(R.id.save_product_button)

        saveProductButton.setOnClickListener {
            val name = productName.text.toString()
            val price = productPrice.text.toString().toDoubleOrNull() ?: 0.0
            val quantity = productQuantity.text.toString().toIntOrNull() ?: 0
            val category = productCategory.text.toString()
            val inStock = productInStock.isChecked
            val producto = Producto(name, price, quantity, category, inStock)
            // Guardar el producto en la lista compartida
            ProductRepository.productos.add(producto)

            Toast.makeText(this, "Producto guardado", Toast.LENGTH_SHORT).show()
            finish() // Cierra la actividad y vuelve al menú
        }
    }
}